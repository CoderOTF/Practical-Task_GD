<?php
/*
Plugin Name:  Inquiry Form
Plugin URI:   https://www.custom.com 
Description:  A short little description of the plugin. It will be displayed on the Plugins page in WordPress admin area. 
Version:      1.0
Author:       Trupti 
Author URI:   https://www.practical.com
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  wpb-tutorial
Domain Path:  /languages
*/


function registraion_shortcode () {
$registraion .= '<div class="custom-form">
    <div class="errors-toast" id="aj_error" style="display:none"></div>
    <form class="registration-form" id="registration_frm" novalidate="novalidate">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="name" class="control-label">Name <span class="red-text">*</span></label>
                    <input class="form-control" type="text" name="name" id="name" maxlength="10">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label class="control-label">Contact No.<span class="red-text">*</span></label>
                    <input class="form-control" type="number" name="contact" id="contact" maxlength="10">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label class="control-label">Message <span class="red-text">*</span></label>
                     <textarea id="message" name="message" required ></textarea>
                </div>
            </div>
        </div>
       
        <input type="hidden" name="action" value="user_registration_data">
        <input type="submit" class="reg_btn" value="submit" name="submit">
   </form>
</div>';

return $registraion;
}
add_shortcode ('registraion', 'registraion_shortcode');



add_action('admin_menu', 'custom_admin_menu');
function custom_admin_menu() {
    add_menu_page('Add New', 'WP List Talble (WP Table)', 'manage_options', 'add_new_frm', 'add_new_data_callback');
    add_submenu_page( 'add_new_frm', 'Add New', 'Add New','manage_options', 'add_new', 'add_new_data_callback');
}


function add_new_data_callback() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    echo "Inquiry Data";

    global $wpdb;
    $table_name = $wpdb->prefix . "mycustomtable";

    $retrieve_data = $wpdb->get_results( "SELECT * FROM $table_name" );
   	foreach ($retrieve_data as $retrieved_data){
   		//print_r($retrieved_data);
   		?>
   		<li><?php echo $retrieved_data->id;?></li>
		<li><?php echo $retrieved_data->name;?></li>
		<li><?php echo $retrieved_data->contact;?></li>
		<li><?php echo $retrieved_data->message;?></li>
		 <?php
		   	}
}


function my_plugin_create_db() {

	global $wpdb;
	$table_name = $wpdb->prefix . 'mycustomtable';
	
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE $table_name (
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		name tinytext NOT NULL,
		contact text NOT NULL,
		message varchar(55) NOT NULL,
		PRIMARY KEY  (id)
	) $charset_collate;";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );

	 if(isset($_POST['Submit'])){
        $name = trim($_POST["name"]);
        $contact = trim($_POST["contact"]);
        $message = trim($_POST["message"]);
    }

    $data = array(
        'name' => $_POST['name'],
        'contact' => $_POST['contact'],
        'message' => $_POST['message'],
    );

    $wpdb->insert('wp_mycustomtable', $data);

}

function pluginprefix_activate() { 
   my_plugin_create_db();
}
register_activation_hook( __FILE__, 'pluginprefix_activate' );


   