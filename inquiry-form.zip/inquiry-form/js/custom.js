jQuery(document).ready(function() {

     jQuery("#registration_frm").validate({
        ignore: "",
        rules: {
            name: "required",
            contact: "required",
            message: "required",
            
        },
        messages: {
            name: "Please enter your firstname",
            contact: "Please enter your lastname",
            message: "Please enter username",
           
        },
        onkeyup: false
    });

    jQuery('#registration_frm').submit(function(e){
        e.preventDefault();
    var name = jQuery("#name").val();
    console.log(name);
    jQuery.ajax({ 
         data: {action: 'user_registration_data', name:name},
         type: 'post',
         url:ajaxPar.ajaxUrl,
         success: function(data) {
             // console.log(data); 
              var json_data = JSON.parse(data);
               if(json_data.status == 'success'){
                        jQuery("#aj_error").css("display", "block");
                        jQuery('#aj_error').html(json_data.message);
                    } else {
                        jQuery('.loader').hide();
                        jQuery(".reg_btn").prop('disabled', false);
                        jQuery("#aj_error").css("display", "block");
                         jQuery('#aj_error').html(json_data.message);
                     } 
                    

        },
        error: function (data) {
                    console.log('An error occurred.');
                },
    });

});
  
   

    // var contactForm = jQuery("#registration_frm");
    // contactForm.on("submit", function(e) {
    //     e.preventDefault();
    //     if(!jQuery("#registration_frm").valid()) 
    //     {return false;}
    // 	jQuery('.loader').show();
    // 	jQuery(".reg_btn").prop('disabled', true);
    //     var name = jQuery('#name').val();
    //     var formData = jQuery("#registration_frm").serialize();
    //     var passData = new FormData(this);
    //     if(name != ''){            
    //         jQuery.ajax({
    //             url:ajaxPar.ajaxUrl,
    //             type: 'POST',
    //             processData: false,
    //             contentType: false,
    //             data:passData,
    //             success: function (data) {
    //                 console.log(data);
    //                  var json_data = JSON.parse(data);
    //                  console.log(json_data);
    //                 if(json_data.status == 'success'){
    //                     jQuery("#aj_error").css("display", "block");
    //                     jQuery('#aj_error').html(json_data.message);
    //                 } else {
    //                     jQuery('.loader').hide();
    //                     jQuery(".reg_btn").prop('disabled', false);
    //                     jQuery("#aj_error").css("display", "block");
    //                      jQuery('#aj_error').html(json_data.message);
    //                  } 
    //             },
    //             error: function (data) {
    //                 console.log('An error occurred.');
    //             },
    //         });
    //     }     
    // });
});